<?php

namespace App\Http\Controllers;

class BlogController extends Controller
{
    public function show()
    {
        return view('blog');
    }
}
