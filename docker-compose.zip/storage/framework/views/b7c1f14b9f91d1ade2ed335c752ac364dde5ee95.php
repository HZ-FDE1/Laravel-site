<head>
    <link rel="stylesheet" href="css/style-error.css">
    <title>Server Error</title>
</head>
<?php $__env->startSection('content'); ?>
    <main>
            <div class="errorCode1">
                <h1 class="errorTitle1">500 Internal Server Error</h1>
                <div class="errorCaption1">
                    <h1>Oops!  It looks like the server there is something wrong with the server. Try again later!</h1>
                    <h2>We are sorry. You can always try to refresh the page, or go back to the Home Page! </h2>
                    <a href="<?php echo e(url('/')); ?>">
                        <button cLass="errorButton"><strong>Home Page</strong></button>
                    </a>
                </div>
            </div>
            <img class="serverGIF" src="/img/hardware1.gif">
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\OneDrive\Bureaublad\laravel-portfolio-UBaron\resources\views/errors/500.blade.php ENDPATH**/ ?>
