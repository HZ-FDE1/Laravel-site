    <head>
        <link rel="stylesheet" href="/css/style-article.css">
        <title>Create Article</title>
    </head>
    <?php $__env->startSection('content'); ?>
        <div id="wrapper" class="contentCreateArticle">
            <div id="page" class="container">
                <h1>Update An Article</h1>

                <form method="POST" action="<?php echo e(route('articles.update' , $article)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="Field">
                        <label class="Label"> Title</label>

                            <div class="control">
                                <input class="input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 320px; height: 50px; font-size: 30px; border-radius: 10px" type="text" name="title" value="<?php echo e(old('title')); ?>"></input>

                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="help is-danger" style="color: red;"><strong><?php echo e($errors->first('title')); ?></strong> </p>
                                <p style="color: red;"><strong>It seems like you didn't fill in this field.</strong></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="Field">
                            <label class="Label"> Excerpt</label>

                            <div class="control">
                                <textarea class="textarea <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 320px; height: 130px; font-size: 30px; border-radius: 10px" type="text" name="excerpt"}><?php echo e(old('excerpt')); ?></textarea>
                                <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red;" class="help is-danger"><strong><?php echo e($errors->first('excerpt')); ?></strong></p>
                                <p style="color: red;"><strong>It seems like you didn't fill in this field.</strong></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="Field">
                            <label class="Label"> Body</label>

                            <div class="control">
                                <textarea class="textarea <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  style="width: 320px; height: 200px; font-size: 30px; border-radius: 10px" type="text" name="body"><?php echo e(old('body')); ?></textarea>
                                <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red;" class="help is-danger"><strong><?php echo e($errors->first('body')); ?> </strong></p>
                                <p style="color: red;"><strong>It seems like you didn't fill in this field.</strong></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-link" type="submit">Submit</button>
                        </div>
                    </div>
                </form>
                            <form method="POST" action="<?php echo e(route('articles.destroy', $article)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="button is-link" type="submit">Delete</button>
                        </form>
        </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\OneDrive\Bureaublad\laravel-portfolio-UBaron\resources\views/articles/edit.blade.php ENDPATH**/ ?>