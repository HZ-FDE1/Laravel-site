<head>
    <link rel="stylesheet" href="/css/style-faq.css">
    <title>Create FAQ</title>
</head>
<?php $__env->startSection('content'); ?>
    <div id="wrapper" class="contentCreateFaq">
        <div id="page" class="container">
            <h1>Create A New Article</h1>

            <form method="POST" action="<?php echo e(route('faq.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="Field">
                    <label class="Label"> Question</label>

                    <div class="control">
                        <input class="input" type="text" name="question">
                    </div>
                </div>

                <div class="Field">
                    <label class="Label"> Answer</label>

                    <div class="control">
                        <textarea class="textarea" name="answer"></textarea>
                    </div>
                </div>

                <div class="Field">
                    <label class="Label"> Link</label>

                    <div class="control">
                        <textarea class="textarea" name="link"></textarea>
                    </div>
                </div>

                <div class="field is-grouped">
                    <div class="control">
                        <button class="button is-link" type="submit">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\OneDrive\Bureaublad\laravel-portfolio-UBaron\resources\views/faq/create.blade.php ENDPATH**/ ?>