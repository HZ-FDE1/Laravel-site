<head>
    <link rel="stylesheet" href="css/style-error.css">
    <title>Page Not Found!</title>
</head>
<?php $__env->startSection('content'); ?>
    <main>
    <div class="errorCode1">
            <h1 class="errorTitle">404 PAGE NOT FOUND</h1>
        <div class="errorCaption">
            <h1>Oh No! It looks like this page does not exist or got deleted. Don't worry!</h1>
            <h2>Check if the URL has been filled in correctly, or return to the Home Page. </h2>
            <a href="<?php echo e(url('/')); ?>">
            <button cLass="errorButton"><strong>Home Page</strong></button>
            </a>

        </div>
    </div>
        <img class="panicGIF" src="/img/spongebob-panic.gif">
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\OneDrive\Bureaublad\laravel-portfolio-UBaron\resources\views/errors/404.blade.php ENDPATH**/ ?>
