<head>
    <link rel="stylesheet" href="/css/style-article.css">
    <link rel="stylesheet" href="/css/style-general.css">
    <title>Create Article</title>
</head>
<?php $__env->startSection('content'); ?>
    <div id="wrapper" class="contentCreateArticle">
        <div id="page" class="container">
            <h1 style="width: 400px">Create A New Article</h1>

            <form method="POST" action="<?php echo e(route('articles.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="Field">
                    <label class="Label"><strong>Title</strong></label>
                    <input class="input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 320px; height: 50px; font-size: 30px; border-radius: 10px" type="text" name="title" value="<?php echo e(old('title')); ?>" placeholder="Type your title here">
                    <div class="control">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="background-color: indianred; width: 320px; height: 70px;" class="foutmelding">
                            <p class="help is-danger" style="color: red; position: relative; left: 10px; top: 5px"><strong><?php echo e($message); ?></strong></p>
                            <p style="color: red; position: relative; left: 10px"><strong>It seems like you didn't fill in this field.</strong></p>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <br>

                <div class="Field">
                    <label class="Label"><strong>Excerpt</strong></label>

                    <div class="control">
                        <textarea class="textarea <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 320px; height: 130px; font-size: 30px; border-radius: 10px" type="text" name="excerpt" placeholder="Type your excerpt here"><?php echo e(old('excerpt')); ?></textarea>
                        <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red;" class="help is-danger"><strong><?php echo e($message); ?></strong></p>
                        <p style="color: red;"><strong>It seems like you didn't fill in this field.</strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <br>

                <div class="Field">
                    <label class="Label"><strong>Body</strong></label>

                    <div class="control">
                        <textarea class="textarea <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="width: 320px; height: 200px; font-size: 30px; border-radius: 10px;" type="text" name="body" placeholder="Type your body here"><?php echo e(old('body')); ?></textarea>
                        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="color: red;" class="help is-danger"><strong><?php echo e($message); ?></strong></p>
                        <p style="color: red;"><strong>It seems like you didn't fill in this field.</strong></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="field is-grouped">
                    <div class="control">
                        <button style="position: relative;top: 20px; width: 320px; height: 30px; background-color: gray; font-size: 15px" class="button is-link" type="submit"><strong>Submit</strong></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\OneDrive\Bureaublad\laravel-portfolio-UBaron\resources\views/articles/create.blade.php ENDPATH**/ ?>