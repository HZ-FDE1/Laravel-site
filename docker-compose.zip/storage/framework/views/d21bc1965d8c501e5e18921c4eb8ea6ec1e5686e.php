<?php $__env->startSection('content'); ?>
    <head>
        <link rel="stylesheet" href="css/style-index.css">
        <title>Home Page</title>
    </head>

<h1 class="typewriter"> Hi, ik ben Uriël :)</h1>
<main>
    <div class="hoverpic">
        <img class="profilepicback" src="img/unicornme.png" alt="ProfilePic2">
        <img class="profilepicfront" src="img/WeLAN.png" alt="ProfilePic1">


        <section class="waaromict">
            <h1> <u>Waarom past ICT bij mij?</u></h1>

            <h2>
                <p> De reden waarom ik denk dat ICT bij mij past,
                    is dat ik ben opgegroeid met (spel)computers.
                    Zo vind ik het interessant hoe een computer, website of game werkt.
                    Omdat ik het altijd zo interessant heb gevonden,
                    denk ik deze opleiding goed bij mij past.
                </p>
                <p>

                </p>
                <p> Na mijn opleiding wil ik mezelf specialiseren in het vakgebied
                    <u>Cyber Security</u>. Als Ethisch Hacker moet je de kwetsbaarheden vinden
                    in soft- en hardware, en daarvoor moet je goed out of the box kunnen denken.
                    En dat is ook de reden waarom het mij zo interessant vind, zo moet je
                    proberen een weg te vinden om in die bepaalde soft- of hardware te komen.
                </p>
            </h2>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>