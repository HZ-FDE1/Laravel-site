<head>
    <link rel="stylesheet" href="/css/style-article.css">
    <title>Grades</title>
</head>
<?php $__env->startSection('content'); ?>
    <body>
    <div class="ArticleContent">
        <a href="<?php echo e(route('grades.create')); ?>" >
            <button> Add your grades here!</button>
        </a>
        <ul>
            <table border="6px" width="1000" height="1000" class="gradeTable">
                <tr>
                    <th bgcolor="#696969">Course Name</th>
                    <th bgcolor="#696969">Test Name</th>
                    <th bgcolor="#696969">Best Grade</th>
                    <th bgcolor="#696969">Edit</th>
                </tr>
            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($grade->course_name); ?></td>
                        <td> <?php echo e($grade->test_name); ?></td>
                        <td> <?php echo e($grade->best_grade); ?></td>
                        <td> <a href="<?php echo e(route('grades.edit', $grade)); ?>" >
            <button> Edit!</button>
        </a></td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </ul>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\laravel-portfolio-UBaron\resources\views/grades/index.blade.php ENDPATH**/ ?>