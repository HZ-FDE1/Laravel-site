<head>
    <link rel="stylesheet" href="/css/style-article.css">
    <title>Articles</title>
</head>
<?php $__env->startSection('content'); ?>
    <body>
    <div class="ArticleContent">
        <a href="<?php echo e(route('articles.index')); ?>" >
            <button>All Articles :D</button>
        </a>
        <div>
        <ul>
                <h1> <?php echo e($article->title); ?></h1>
                <h3> <?php echo e($article->body); ?></h3>
        </ul>
        </div>
        <a href="<?php echo e(route('articles.edit', $article)); ?>" >
            <button>EDIT</button>
        </a>
    </div>
    <img class="eviedehond" src="/img/evie.jpg" alt="fotoEvie" width="300px" height="300px">
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\laravel-portfolio-UBaron\resources\views/articles/show.blade.php ENDPATH**/ ?>