<head>
    <link rel="stylesheet" href="/css/style-faq.css">
    <title>Create FAQ</title>
</head>
<?php $__env->startSection('content'); ?>
    <div id="wrapper" class="contentCreateFaq">
        <div id="page" class="container">
            <h1>Update An FAQ!</h1>

            <form method="POST" action="<?php echo e(route('faq.update', $faq)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="Field">
                    <label class="Label"> Question</label>

                    <div class="control">
                        <input class="input <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="question" value="<?php echo e($faq->question); ?> <?php echo e(old('question')); ?>">
                        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="help is-danger"><?php echo e($errors->first('question')); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="Field">
                    <label class="Label"> Answer</label>

                    <div class="control">
                        <textarea class="textarea <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="answer"><?php echo e($faq->answer); ?> <?php echo e(old('answer')); ?></textarea>
                        <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="help is-danger"><?php echo e($errors->first('answer')); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="Field">
                    <label class="Label"> Link</label>

                    <div class="control">
                        <textarea class="textarea" name="body"><?php echo e($faq->link); ?> <?php echo e(old('link')); ?></textarea>
                        <p class="help is-danger"><?php echo e($errors->first('link')); ?></p>
                    </div>
                </div>

                <div class="field is-grouped">
                    <div class="control">
                        <button class="button is-link" type="submit">Submit</button>
                    </div>
                </div>
            </form>
            <form method="POST" action="<?php echo e(route('faq.destroy', $faq)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="button is-link" type="submit">Delete</button>
            </form>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\baron\laravel-portfolio-UBaron\resources\views/faq/edit.blade.php ENDPATH**/ ?>