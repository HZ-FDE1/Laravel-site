<head>
    <link rel="stylesheet" href="/css/style-article.css">
    <title>Article</title>
</head>
<?php $__env->startSection('content'); ?>
    <body>
    <div class="ArticleContent">
        <a href="<?php echo e(route('articles.create')); ?>" >
            <button> Make an Article here!</button>
        </a>
        <ul>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1> <a href="<?php echo e(route('articles.show', $article)); ?>"> <?php echo e($article->title); ?> </a> </h1>
                <h2> <?php echo e($article->excerpt); ?></h2>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <img class="eviemain" src="/img/evie.jpg" alt="fotoEvie" width="450px" height="900px">
    </body>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/articles/index.blade.php ENDPATH**/ ?>